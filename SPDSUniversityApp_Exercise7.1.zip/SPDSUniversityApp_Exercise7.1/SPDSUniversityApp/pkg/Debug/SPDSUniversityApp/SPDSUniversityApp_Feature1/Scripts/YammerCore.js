﻿function postMessagetoYammer(ItemURL, message, group_id) {
    var testMessage = { "&body": "Hello Test, have you seen this" + ItemURL };
  
    yam.platform.request({
        url: "https://api.yammer.com/api/v1/messages.json",
        method: "POST",
        data: {
            "body": testMessage,
            "group_id": group_id
        },
        success: function (msg) {
            console.log("Message Posted Successfully");
        },
        error: function (msg) {
            console.log("Message Posting Error: " + msg.statusText);

        }
    });
}

function likeaMessage(messageid) {

    var endpoint = "https://www.yammer.com/api/v1/messages/liked_by/current.json?message_id=[:id]".replace('[:id]', messageid)
    yam.platform.request({
        url: endpoint,
        data: '',
        method: "POST",
        success: function (msg) {
            console.log("Message liked Successfully");
        },
        error: function (msg) {
            console.log("Message Posting Error: " + msg.statusText);

        }
    });
}

function UnlikeaMessage(messageid) {
    var endpoint = "https://www.yammer.com/api/v1/messages/liked_by/current.json?message_id=[:id]".replace('[:id]', messageid)
    yam.platform.request({
        url: endpoint,
        data: '',
        method: "DELETE",
        success: function (msg) {
            console.log("Message was unliked Successfully");
        },
        error: function (msg) {
            console.log("Message Posting Error: " + msg.statusText);

        }
    });
}
