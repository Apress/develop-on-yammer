﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Json;
using Yammer.OAuthSDK.Utils;
using SPDSUniversityWinPhoneApp.Common;


[DataContract]
public class YammerMessages
{
    [DataMember(Name = "messages")]
    public List<YammerMessage> Messages { get; set; }

    public YammerMessages()
    {
        this.Messages = new List<YammerMessage>();
    }
}
