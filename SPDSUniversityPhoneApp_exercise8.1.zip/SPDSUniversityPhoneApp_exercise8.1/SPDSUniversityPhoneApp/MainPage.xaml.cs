﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Navigation;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Shell;
using SPDSUniversityPhoneApp.Resources;
using Yammer.OAuthSDK.Model;
using Yammer.OAuthSDK.Utils;

namespace SPDSUniversityPhoneApp
{
    public partial class MainPage : PhoneApplicationPage
    {

        string clientId = default(string);
        string clientSecret = default(string);
        string redirectUri = default(string);

        // Constructor
        public MainPage()
        {
            InitializeComponent();

            // Sample code to localize the ApplicationBar
            //BuildLocalizedApplicationBar();

            // we extract these values from the App's Resource Dictionary config 
            clientId = ((App)App.Current).MyOAuthClientInfo.ClientId;
            clientSecret = ((App)App.Current).MyOAuthClientInfo.ClientSecret;
            redirectUri = ((App)App.Current).MyOAuthClientInfo.RedirectUri;

        }

        private void btnSignInWithYammer_Click(object sender, RoutedEventArgs e)
        {
            OAuthUtils.LaunchSignIn(clientId, redirectUri);

        }

        private void UpdateTokenMessage(bool isTokenPresent)
        {
            Dispatcher.BeginInvoke(() => txbIsTokenPresent.Text = isTokenPresent ? txbIsTokenPresent.Text.Replace("No.", "Yes.") : txbIsTokenPresent.Text.Replace("Yes.", "No."));
        }


        private void btnLiketMsgYammer_Click(object sender, RoutedEventArgs e)
        {
            // Call this API to test if the auth token works
            var messageApiEndpoint = new Uri(Constants.ApiEndpoints.current + "?message_id=508413888", UriKind.Absolute);
            String data = "";

            OAuthUtils.PostMessage(messageApiEndpoint, "POST", data, onSuccess: response =>
            {
                // we just dump the unformated json string response into a textbox
                Dispatcher.BeginInvoke(() => txtResponses.Text = "Message Liked");
            },
              onErrorResponse: errorResponse =>
              {
                  Dispatcher.BeginInvoke(() =>
                  {
                      MessageBox.Show(errorResponse.OAuthError.ToString(), "Invalid operation", MessageBoxButton.OK);
                      txtResponses.Text = string.Empty;
                  });
              },
                 onException: ex =>
                 {
                     Dispatcher.BeginInvoke(() =>
                     {
                         MessageBox.Show(ex.ToString(), "Unexpected exception!", MessageBoxButton.OK);
                         txtResponses.Text = string.Empty;
                     });
                 }
         );
            Dispatcher.BeginInvoke(() => txtResponses.Text = "Liking...");

        }

        /// <summary>
        /// UnLike a Message Button event handler to Like a message specified by message_Id
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnUnLikeMsgYammer_Click(object sender, RoutedEventArgs e)
        {
            // Call this API to test if the auth token works
            var messageApiEndpoint = new Uri(Constants.ApiEndpoints.current + "?message_id=508402750", UriKind.Absolute);
            String data = "";

            OAuthUtils.PostMessage(messageApiEndpoint, "DELETE", data, onSuccess: response =>
            {
                // we just dump the unformated json string response into a textbox
                Dispatcher.BeginInvoke(() => txtResponses.Text = "Message Unliked");
            },
              onErrorResponse: errorResponse =>
              {
                  Dispatcher.BeginInvoke(() =>
                  {
                      MessageBox.Show(errorResponse.OAuthError.ToString(), "Invalid operation", MessageBoxButton.OK);
                      txtResponses.Text = string.Empty;
                  });
              },
                 onException: ex =>
                 {
                     Dispatcher.BeginInvoke(() =>
                     {
                         MessageBox.Show(ex.ToString(), "Unexpected exception!", MessageBoxButton.OK);
                         txtResponses.Text = string.Empty;
                     });
                 }
         );
            Dispatcher.BeginInvoke(() => txtResponses.Text = "Unliking...");

        }
        private void btnViewUserYammer_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Uri("/ViewUserInfo.xaml", UriKind.Relative));
        }

        private void ViewallMessage_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Uri("/ViewAllMessages.xaml", UriKind.Relative));
        }
        private void btnSearchUserYammer_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Uri("/SearchUserInfo.xaml", UriKind.Relative));
        }
        private void btnViewUserinGroup_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Uri("/ViewAllUsersinaGroup.xaml", UriKind.Relative));
        }


        private void btnAllUserYammer_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Uri("/ViewAllUsers.xaml", UriKind.Relative));
        }


        private void btnPostMsgYammer_Click(object sender, RoutedEventArgs e)
        {
            // Call this API to test if the auth token works
            var messageApiEndpoint = new Uri(Constants.ApiEndpoints.Message, UriKind.Absolute);
            String data = "body=We are in process of launching more technical trainings this year. Check our training portal home page for more details ";

            OAuthUtils.PostMessage(messageApiEndpoint, "POST", data, onSuccess: response =>
            {
                // we just dump the unformated json string response into a textbox
                Dispatcher.BeginInvoke(() => txtResponses.Text = "Message Posted");
            },
              onErrorResponse: errorResponse =>
              {
                  Dispatcher.BeginInvoke(() =>
                  {
                      MessageBox.Show(errorResponse.OAuthError.ToString(), "Invalid operation", MessageBoxButton.OK);
                      txtResponses.Text = string.Empty;
                  });
              },
                 onException: ex =>
                 {
                     Dispatcher.BeginInvoke(() =>
                     {
                         MessageBox.Show(ex.ToString(), "Unexpected exception!", MessageBoxButton.OK);
                         txtResponses.Text = string.Empty;
                     });
                 }
         );
            Dispatcher.BeginInvoke(() => txtResponses.Text = "Posting...");

        }


   



        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
            base.OnNavigatedTo(e);

            // Check the arguments from the query string passed to the page.
            IDictionary<string, string> uriParams = NavigationContext.QueryString;

            // "Approve"
            if (uriParams.ContainsKey(Constants.OAuthParameters.Code) && uriParams.ContainsKey(Constants.OAuthParameters.State) && e.NavigationMode != NavigationMode.Back)
            {
                OAuthUtils.HandleApprove(
                    clientId,
                    clientSecret,
                    uriParams[Constants.OAuthParameters.Code],
                    uriParams[Constants.OAuthParameters.State],
                    onSuccess: () =>
                    {
                        UpdateTokenMessage(true);
                    }, onCSRF: () =>
                    {
                        MessageBox.Show("Unknown 'state' parameter. Discarding the authentication attempt.", "Invalid redirect.", MessageBoxButton.OK);
                    }, onErrorResponse: errorResponse =>
                    {
                        Dispatcher.BeginInvoke(() => MessageBox.Show(errorResponse.OAuthError.ToString(), "Invalid operation", MessageBoxButton.OK));
                    }, onException: ex =>
                    {
                        Dispatcher.BeginInvoke(() => MessageBox.Show(ex.ToString(), "Unexpected exception!", MessageBoxButton.OK));
                    }
                );
            }
            // "Deny"
            else if (uriParams.ContainsKey(Constants.OAuthParameters.Error) && e.NavigationMode != NavigationMode.Back)
            {
                string error, errorDescription;
                error = uriParams[Constants.OAuthParameters.Error];
                uriParams.TryGetValue(Constants.OAuthParameters.ErrorDescription, out errorDescription);

                string msg = string.Format("error: {0}\nerror_description:{1}", error, errorDescription);
                MessageBox.Show(msg, "Error response is received.", MessageBoxButton.OK);

                OAuthUtils.DeleteStoredToken();

                UpdateTokenMessage(false);
            }

            // if token already exist
            if (!string.IsNullOrEmpty(OAuthUtils.AccessToken))
            {
                // UpdateTokenMessage(true);
            }
        }



        // Sample code for building a localized ApplicationBar
        //private void BuildLocalizedApplicationBar()
        //{
        //    // Set the page's ApplicationBar to a new instance of ApplicationBar.
        //    ApplicationBar = new ApplicationBar();

        //    // Create a new button and set the text value to the localized string from AppResources.
        //    ApplicationBarIconButton appBarButton = new ApplicationBarIconButton(new Uri("/Assets/AppBar/appbar.add.rest.png", UriKind.Relative));
        //    appBarButton.Text = AppResources.AppBarButtonText;
        //    ApplicationBar.Buttons.Add(appBarButton);

        //    // Create a new menu item with the localized string from AppResources.
        //    ApplicationBarMenuItem appBarMenuItem = new ApplicationBarMenuItem(AppResources.AppBarMenuItemText);
        //    ApplicationBar.MenuItems.Add(appBarMenuItem);
        //}
    }
}