﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Navigation;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Shell;
using Yammer.OAuthSDK.Utils;
using Yammer.OAuthSDK.Model;
using Yammer.OAuthSDK.Utils;
using System.IO;
using System.Text;


namespace SPDSUniversityPhoneApp
{
    public partial class ViewAllMessages : PhoneApplicationPage
    {
        public ViewAllMessages()
        {
            InitializeComponent();
            Loaddata();
        }

        private void Loaddata()
        {
            // Call this API to test if the auth token works
            var messageApiEndpoint = new Uri(Constants.ApiEndpoints.Message, UriKind.Absolute);

            OAuthUtils.GetJsonFromApi(messageApiEndpoint, onSuccess: response =>
            {
                byte[] byteArray = System.Text.UTF8Encoding.UTF8.GetBytes(response);
                MemoryStream res = new MemoryStream(byteArray);

                YammerMessages msgs = SerializationUtils.DeserializeJson<YammerMessages>(res);

                ListBoxAllMessage.DataContext = msgs.Messages;
                ListBoxAllMessage.ItemsSource = msgs.Messages;

                // we just dump the unformated json string response into a textbox
                Dispatcher.BeginInvoke(() => txtResponses.Text = "Messages Retrieved");
            },
              onErrorResponse: errorResponse =>
              {
                  Dispatcher.BeginInvoke(() =>
                  {
                      MessageBox.Show(errorResponse.OAuthError.ToString(), "Invalid operation", MessageBoxButton.OK);
                      txtResponses.Text = string.Empty;
                  });
              },
                 onException: ex =>
                 {
                     Dispatcher.BeginInvoke(() =>
                     {
                         MessageBox.Show(ex.ToString(), "Unexpected exception!", MessageBoxButton.OK);
                         txtResponses.Text = string.Empty;
                     });
                 }
         );
            Dispatcher.BeginInvoke(() => txtResponses.Text = "Retrieving ...");
        }

    }

    }
