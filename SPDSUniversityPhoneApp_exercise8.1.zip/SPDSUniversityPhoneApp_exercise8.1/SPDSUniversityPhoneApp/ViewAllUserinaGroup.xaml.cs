﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Navigation;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Shell;
using Yammer.OAuthSDK.Model;
using Yammer.OAuthSDK.Utils;
using SPDSUniversityWinPhoneApp.Common;
using System.IO;
using System.Text;


namespace SPDSUniversityPhoneApp
{
    public partial class ViewAllUserinaGroup : PhoneApplicationPage
    {
        public ViewAllUserinaGroup()
        {
            InitializeComponent();
            Loaddata();
        }

        private void Loaddata()
        {
            // Call this API to test if the auth token works
            var GroupId = 4659506;
            var messageApiEndpoint = new Uri(Constants.ApiEndpoints.ViewUserinGroup + GroupId + ".json", UriKind.Absolute);

            OAuthUtils.GetJsonFromApi(messageApiEndpoint, onSuccess: response =>
            {
                byte[] byteArray = System.Text.UTF8Encoding.UTF8.GetBytes(response);
                MemoryStream res = new MemoryStream(byteArray);

                List<YammerUser> users = SerializationUtils.DeserializeJson<List<YammerUser>>(res);

                ListBoxAllUsers.DataContext = users;
                ListBoxAllUsers.ItemsSource = users;

                // we just dump the unformated json string response into a textbox
                Dispatcher.BeginInvoke(() => txtResponses.Text = "Users Retrieved");
            },
              onErrorResponse: errorResponse =>
              {
                  Dispatcher.BeginInvoke(() =>
                  {
                      MessageBox.Show(errorResponse.OAuthError.ToString(), "Invalid operation", MessageBoxButton.OK);
                      txtResponses.Text = string.Empty;
                  });
              },
                 onException: ex =>
                 {
                     Dispatcher.BeginInvoke(() =>
                     {
                         MessageBox.Show(ex.ToString(), "Unexpected exception!", MessageBoxButton.OK);
                         txtResponses.Text = string.Empty;
                     });
                 }
         );
            Dispatcher.BeginInvoke(() => txtResponses.Text = "Retrieving ...");
        }

    }
}