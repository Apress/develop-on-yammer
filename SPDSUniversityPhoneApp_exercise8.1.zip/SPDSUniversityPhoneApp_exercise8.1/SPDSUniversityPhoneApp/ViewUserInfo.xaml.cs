﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Navigation;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Shell;
using Yammer.OAuthSDK.Model;
using Yammer.OAuthSDK.Utils;
using System.IO;
using System.Text;
using SPDSUniversityWinPhoneApp.Common;


namespace SPDSUniversityPhoneApp
{
    public partial class ViewUserInfo : PhoneApplicationPage
    {
        public ViewUserInfo()
        {
            InitializeComponent();
        }

        private void RenderUI(YammerUser yammeruser)
        {
            tbUserName.Text = yammeruser.FullName;
            tbjob_title.Text = yammeruser.JobTitle;
            tbFollowers.Text = yammeruser.UserStats.Following.ToString();

        }

        private void Loaddata()
        {
            // Call this API to test if the auth token works
            var messageApiEndpoint = new Uri(Constants.ApiEndpoints.CurrentUserUrl, UriKind.Absolute);

            OAuthUtils.GetJsonFromApi(messageApiEndpoint, onSuccess: response =>
            {
                string s = response;
                byte[] byteArray = System.Text.UTF8Encoding.UTF8.GetBytes(response);
                MemoryStream res = new MemoryStream(byteArray);

                YammerUser YammerUser = SerializationUtils.DeserializeJson<YammerUser>(res);

                RenderUI(YammerUser);

                // we just dump the unformated json string response into a textbox
                Dispatcher.BeginInvoke(() => txtResponses.Text = "User Info Retrieved");
            },
              onErrorResponse: errorResponse =>
              {
                  Dispatcher.BeginInvoke(() =>
                  {
                      MessageBox.Show(errorResponse.OAuthError.ToString(), "Invalid operation", MessageBoxButton.OK);
                      txtResponses.Text = string.Empty;
                  });
              },
                 onException: ex =>
                 {
                     Dispatcher.BeginInvoke(() =>
                     {
                         MessageBox.Show(ex.ToString(), "Unexpected exception!", MessageBoxButton.OK);
                         txtResponses.Text = string.Empty;
                     });
                 }
         );
            Dispatcher.BeginInvoke(() => txtResponses.Text = "Retrieving ...");
        }

    }
}