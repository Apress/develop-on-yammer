﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Net;
using System.IO;

namespace SPDSUniversityWebApplication.App_Code
{
    public class YammerUtility
    {
        private static HttpWebResponse HTTPWebRes;
        private static HttpWebRequest HTTPWebReq;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="Url"></param>
        /// <param name="authHeader"></param>
        /// <param name="AddCookies"></param>
        /// <returns></returns>
        public static string InvokeHttpGetRequest(string Url, string authHeader = null, bool AddCookies = false)
        {
            string results = string.Empty;

            try
            {
                HTTPWebReq = WebRequest.CreateHttp(Url);
                HTTPWebReq.Method = "GET";



                if (!string.IsNullOrEmpty(authHeader))
                    HTTPWebReq.Headers.Add("Authorization", "Bearer " + authHeader);

                HTTPWebRes = (HttpWebResponse)HTTPWebReq.GetResponse();

                Stream dataStream = HTTPWebRes.GetResponseStream();
                StreamReader reader = new StreamReader(dataStream);

                results = reader.ReadToEnd();

                reader.Close();
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error in MakeGetRequest: " + ex.Message);
            }

            return results;
        }

    }
}
