﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Configuration;

namespace SPDSUniversityWebApplication
{
    public partial class _Default : Page
    {
        /// <summary>
        /// Page load event to check if query string contains a key called "Code"
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {

            string qsCode = Request.QueryString["Code"];
            if (qsCode != null)
            {
                txtCode.Text = qsCode;
                Obtain_Access_Token();
            }
            else
            {

            }
        }

        /// <summary>
        /// Obtain the access Token
        /// </summary>
        private void Obtain_Access_Token()
        {

            string accessToken = default(string);
            string AccesTokenURL = WebConfigurationManager.AppSettings["AccessTokenURL"] + "client_id=" + WebConfigurationManager.AppSettings["client_id"] + "&client_secret=" + WebConfigurationManager.AppSettings["client_secret"] + "&code=" + txtCode.Text;
            string response = SPDSUniversityWebApplication.App_Code.YammerUtility.InvokeHttpGetRequest(AccesTokenURL);
            if (!string.IsNullOrEmpty(response))
            {
                SPDSUniversityWebApplication.App_Code.AccessToken jat = SPDSUniversityWebApplication.App_Code.AccessToken.GetObjectInstanceFromJson(response);

                if (!string.IsNullOrEmpty(jat.TokenResponse.Token))
                {
                    accessToken = jat.TokenResponse.Token;
                    lbllogin.Text = "Welcome " + jat.CurrentUser.FullName;
                    txtaccesstoken.Text = accessToken;
                    Session["accesstoken"] = accessToken;
                }
            }
        }


    }
}