﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Configuration;

namespace SPDSUniversityWebApplication.Account
{
    public partial class Login : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
           
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void imgbtnLogin_Click(object sender, ImageClickEventArgs e)
        {
            string YammerURL = WebConfigurationManager.AppSettings["OAuthURL"] + WebConfigurationManager.AppSettings["client_id"] + "&redirect_uri=" + WebConfigurationManager.AppSettings["redirect_uri"];
            Response.Redirect(YammerURL);
        }

    }
}