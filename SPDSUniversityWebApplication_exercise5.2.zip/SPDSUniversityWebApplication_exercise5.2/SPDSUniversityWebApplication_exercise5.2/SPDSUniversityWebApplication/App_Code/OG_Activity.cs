﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Json;
using System.IO;
using System.Xml.Serialization;
using System.Diagnostics;

namespace SPDSUniversityWebApplication.App_Code
{
    /// <summary>
    /// Summary description for YammerOG_Activity
    /// </summary>
    [DataContract]
    public class OG_Activity
    {
        [DataMember(Name = "actor")]
        public OG_Actor Actor { get; set; }

        [DataMember(Name = "action")]
        public string Action { get; set; }

        [DataMember(Name = "object")]
        public OG_GraphObj_Instance Object { get; set; }

        [DataMember(Name = "message")]
        public string Message { get; set; }

        [DataMember(Name = "private")]
        public bool Private { get; set; }

        [DataMember(Name = "users")]
        public List<OG_Actor> Users { get; set; }

        public OG_Activity()
        {
            this.Actor = new OG_Actor();
            this.Object = new OG_GraphObj_Instance();
            this.Users = new List<OG_Actor>();
            this.Private = false;
        }
    }
}
