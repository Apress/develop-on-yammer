﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Json;
using System.IO;
using System.Xml.Serialization;
using System.Diagnostics;

namespace SPDSUniversityWebApplication.App_Code
{
    /// <summary>
    /// This class represents the Actor, user who acts on the object, using attributes name and email
    /// </summary>
    [DataContract]
    public class OG_Actor
    {
        [DataMember(Name = "name")]
        public string Name { get; set; }

        [DataMember(Name = "email")]
        public string Email { get; set; }

        public OG_Actor() { }

        public OG_Actor(string name, string email)
        {
            this.Name = name;
            this.Email = email;
        }
    }
}
