﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Json;
using System.IO;
using System.Xml.Serialization;
using System.Diagnostics;

namespace SPDSUniversityWebApplication.App_Code
{
    /// <summary>
    /// This class represents the Activity Object and a function to convert object into string
    /// </summary>
    [DataContract]
    public class OG_GraphObj
    {
        [DataMember(Name = "activity")]
        public OG_Activity Activity { get; set; }

        public OG_GraphObj()
        {
            this.Activity = new OG_Activity();
        }

        public override string ToString()
        {
            string jsonData = string.Empty;

            try
            {
                DataContractJsonSerializer ys = new DataContractJsonSerializer(typeof(OG_GraphObj));
                MemoryStream msBack = new MemoryStream();
                ys.WriteObject(msBack, this);
                msBack.Position = 0;
                StreamReader sr = new StreamReader(msBack);
                jsonData = sr.ReadToEnd();

                //replace \\ with / as in jsonData
                jsonData = jsonData.Replace("\\/", "/");
            }
            catch (Exception ex)
            {
                Debug.WriteLine("An Error occurred in serializing into string: " + ex.Message);
            }

            return jsonData;
        }
    }
}
