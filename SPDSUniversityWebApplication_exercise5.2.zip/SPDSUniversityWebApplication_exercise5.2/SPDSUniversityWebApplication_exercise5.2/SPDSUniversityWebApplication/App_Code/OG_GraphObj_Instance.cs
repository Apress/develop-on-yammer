﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Xml.Serialization;
using System.Diagnostics;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Json;


namespace SPDSUniversityWebApplication.App_Code
{
    /// <summary>
    /// This class represents the actual Graph Object which describes the object using attributes 
    /// like URL (Unique property), type of object, image, name and title of the object
    /// </summary>
    [DataContract]
    public class OG_GraphObj_Instance
    {
        [DataMember(Name = "url")]
        public string Url { get; set; }

        [DataMember(Name = "type")]
        public string Type { get; set; }

        [DataMember(Name = "title")]
        public string Title { get; set; }

        [DataMember(Name = "image")]
        public string Image { get; set; }

        [DataMember(Name = "description")]
        public string Description { get; set; }
    }

}
