﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Net;
using System.IO;
using System.Text;

namespace SPDSUniversityWebApplication.App_Code
{
    public class YammerUtility
    {
        private static HttpWebResponse HTTPWebRes;
        private static HttpWebRequest HTTPWebReq;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="Url"></param>
        /// <param name="authHeader"></param>
        /// <param name="AddCookies"></param>
        /// <returns></returns>
        public static string InvokeHttpGetRequest(string Url, string authHeader = null, bool AddCookies = false)
        {
            string results = string.Empty;

            try
            {
                HTTPWebReq = WebRequest.CreateHttp(Url);
                HTTPWebReq.Method = "GET";



                if (!string.IsNullOrEmpty(authHeader))
                    HTTPWebReq.Headers.Add("Authorization", "Bearer " + authHeader);

                HTTPWebRes = (HttpWebResponse)HTTPWebReq.GetResponse();

                Stream dataStream = HTTPWebRes.GetResponseStream();
                StreamReader reader = new StreamReader(dataStream);

                results = reader.ReadToEnd();

                reader.Close();
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error in MakeGetRequest: " + ex.Message);
            }

            return results;
        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="postBody"></param>
        /// <param name="url"></param>
        /// <param name="authHeader"></param>
        /// <param name="contentType"></param>
        /// <returns></returns>
        public static string PostRequesttoYammer(string postBody, string url, string authHeader = null, string contentType = null)
        {
            string results = string.Empty;

            try
            {


                HTTPWebReq = WebRequest.CreateHttp(url);
                HTTPWebReq.Method = "POST";

                if (!string.IsNullOrEmpty(authHeader))
                    HTTPWebReq.Headers.Add("Authorization", "Bearer " + authHeader);

                byte[] postByte = Encoding.UTF8.GetBytes(postBody);

                if (string.IsNullOrEmpty(contentType))
                    HTTPWebReq.ContentType = "application/x-www-form-urlencoded";
                else
                    HTTPWebReq.ContentType = contentType;

                HTTPWebReq.ContentLength = postByte.Length;
                Stream postStream = HTTPWebReq.GetRequestStream();
                postStream.Write(postByte, 0, postByte.Length);
                postStream.Close();

                HTTPWebRes = (HttpWebResponse)HTTPWebReq.GetResponse();
                postStream = HTTPWebRes.GetResponseStream();
                StreamReader postReader = new StreamReader(postStream);

                results = postReader.ReadToEnd();

                postReader.Close();
                postStream.Close();
            }
            catch (Exception ex)
            {

            }

            return results;
        }


    }
}
