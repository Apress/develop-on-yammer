﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Configuration;

namespace SPDSUniversityWebApplication
{
    public partial class _Default : Page
    {
        /// <summary>
        /// Page load event to check if query string contains a key called "Code"
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {

            string qsCode = Request.QueryString["Code"];
            if (qsCode != null)
            {
                txtCode.Text = qsCode;
                Obtain_Access_Token();
            }
            else
            {
                CourseDiv.Visible = false;
                btnWriteDataOG.Visible = false;
                btnWriteDataOGPage.Visible = false;
                btnWriteDataOGPlace.Visible = false;
                btnWriteDataOGPerson.Visible = false;
                btnWriteDataOGVideo.Visible = false;
                btnWriteDataOG_Custom.Visible = false;


            }
        }

        /// <summary>
        /// Obtain the access Token
        /// </summary>
        private void Obtain_Access_Token()
        {

            string accessToken = default(string);
            string AccesTokenURL = WebConfigurationManager.AppSettings["AccessTokenURL"] + "client_id=" + WebConfigurationManager.AppSettings["client_id"] + "&client_secret=" + WebConfigurationManager.AppSettings["client_secret"] + "&code=" + txtCode.Text;
            string response = SPDSUniversityWebApplication.App_Code.YammerUtility.InvokeHttpGetRequest(AccesTokenURL);
            if (!string.IsNullOrEmpty(response))
            {
                SPDSUniversityWebApplication.App_Code.AccessToken jat = SPDSUniversityWebApplication.App_Code.AccessToken.GetObjectInstanceFromJson(response);

                if (!string.IsNullOrEmpty(jat.TokenResponse.Token))
                {
                    accessToken = jat.TokenResponse.Token;
                    lbllogin.Text = "Welcome " + jat.CurrentUser.FullName;
                    txtaccesstoken.Text = accessToken;
                    Session["accesstoken"] = accessToken;
                }
            }
        }

        /// <summary>
        /// Event Handler to write Document object 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnWriteDataOG_Click(object sender, EventArgs e)
        {
            SPDSUniversityWebApplication.App_Code.OG_GraphObj yammergraphobject = new SPDSUniversityWebApplication.App_Code.OG_GraphObj();

            yammergraphobject.Activity.Actor = new SPDSUniversityWebApplication.App_Code.OG_Actor("Pathik Rawal", "pr@spdsuniversity.onmicrosoft.com");
            yammergraphobject.Activity.Message = "Learn the sales process in Microsoft Dynamics CRM.";
            yammergraphobject.Activity.Action = "create";


            SPDSUniversityWebApplication.App_Code.OG_GraphObj_Instance yammergraphobjectinst = new SPDSUniversityWebApplication.App_Code.OG_GraphObj_Instance();

            yammergraphobjectinst.Url = "https://spdsuniversity.sharepoint.com/_layouts/15/WopiFrame.aspx?sourcedoc=%7B7614951D-3C30-4924-B815-1354570EE805%7D&file=2014%20Expenses.xlsx&action=default";
            yammergraphobjectinst.Title = "Microsoft Dynamics CRM 2015 User Guide";
            yammergraphobjectinst.Description = "Microsoft Dynamics CRM 2015 User Guide";
            yammergraphobjectinst.Image = "https://www.yammer.com/api/v1/uploaded_files/29860625/version/28812608/preview/UAPP_LOGO.png";
            yammergraphobjectinst.Type = "document";


            yammergraphobject.Activity.Object = yammergraphobjectinst;

            string postData = yammergraphobject.ToString();
            string activityURL = WebConfigurationManager.AppSettings["activityURL"];
            string response = SPDSUniversityWebApplication.App_Code.YammerUtility.PostRequesttoYammer(postData, activityURL, txtaccesstoken.Text.ToString(), "application/json");

        }

        /// <summary>
        /// Write a Page Object into Yammer.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnWriteDataOGPage_Click(object sender, EventArgs e)
        {
            SPDSUniversityWebApplication.App_Code.OG_GraphObj yammergraphobject = new SPDSUniversityWebApplication.App_Code.OG_GraphObj();

            yammergraphobject.Activity.Actor = new SPDSUniversityWebApplication.App_Code.OG_Actor("Pathik Rawal", "pr@spdsuniversity.onmicrosoft.com");
            yammergraphobject.Activity.Message = "SPDS University's Training Calendar- View updated calendar";
            yammergraphobject.Activity.Action = "create";


            SPDSUniversityWebApplication.App_Code.OG_GraphObj_Instance yammergraphobjectinst = new SPDSUniversityWebApplication.App_Code.OG_GraphObj_Instance();

            yammergraphobjectinst.Url = "https://spdsuniversity.sharepoint.com/sites/SPDS/Lists/Modern%20Calendar/calendar.aspx";
            yammergraphobjectinst.Title = "SPDS University's Training Calendar";
            yammergraphobjectinst.Description = "SPDS University's Training Calendar- upcoming trainings";
            yammergraphobjectinst.Image = "https://www.yammer.com/api/v1/uploaded_files/29860625/version/28812608/preview/UAPP_LOGO.png";
            yammergraphobjectinst.Type = "page";


            yammergraphobject.Activity.Object = yammergraphobjectinst;

            string postData = yammergraphobject.ToString();
            string activityURL = WebConfigurationManager.AppSettings["activityURL"];
            string response = SPDSUniversityWebApplication.App_Code.YammerUtility.PostRequesttoYammer(postData, activityURL, txtaccesstoken.Text.ToString(), "application/json");

        }


        /// <summary>
        ///  Write a Place Object into Yammer.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnWriteDataOGPlace_Click(object sender, EventArgs e)
        {
            SPDSUniversityWebApplication.App_Code.OG_GraphObj yammergraphobject = new SPDSUniversityWebApplication.App_Code.OG_GraphObj();

            yammergraphobject.Activity.Actor = new SPDSUniversityWebApplication.App_Code.OG_Actor("Pathik Rawal", "pr@spdsuniversity.onmicrosoft.com");
            yammergraphobject.Activity.Message = "SPDS's new Training Venue";
            yammergraphobject.Activity.Action = "create";
            SPDSUniversityWebApplication.App_Code.OG_GraphObj_Instance yammergraphobjectinst = new SPDSUniversityWebApplication.App_Code.OG_GraphObj_Instance();

            yammergraphobjectinst.Url = "https://www.google.co.uk/maps/place/Oxford+St,+London/@51.5154003,-0.1412821,17z/data=!3m1!4b1!4m2!3m1!1s0x48761ad554c335c1:0xda2164b934c67c1a?hl=en";
            yammergraphobjectinst.Title = "SPDS's new Training Venue";
            yammergraphobjectinst.Description = "We are in process of moving our training location to a new address in the heart of the city";
            yammergraphobjectinst.Image = "https://www.yammer.com/api/v1/uploaded_files/29860625/version/28812608/preview/UAPP_LOGO.png";
            yammergraphobjectinst.Type = "place";
            yammergraphobject.Activity.Object = yammergraphobjectinst;
            string postData = yammergraphobject.ToString();
            string activityURL = WebConfigurationManager.AppSettings["activityURL"];
            string response = SPDSUniversityWebApplication.App_Code.YammerUtility.PostRequesttoYammer(postData, activityURL, txtaccesstoken.Text.ToString(), "application/json");

        }

        /// <summary>
        /// Write Data into Yammer using object type Person
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnWriteDataOGPerson_Click(object sender, EventArgs e)
        {
            SPDSUniversityWebApplication.App_Code.OG_GraphObj yOG_obj = new SPDSUniversityWebApplication.App_Code.OG_GraphObj();

            yOG_obj.Activity.Actor = new SPDSUniversityWebApplication.App_Code.OG_Actor("Pathik Rawal", "pr@spdsuniversity.onmicrosoft.com");
            yOG_obj.Activity.Message = "Brian Johnson is now #certified  #DynamicCRM2014 expert ";
            yOG_obj.Activity.Action = "create";
            SPDSUniversityWebApplication.App_Code.OG_GraphObj_Instance yOGobjInst = new SPDSUniversityWebApplication.App_Code.OG_GraphObj_Instance();

            yOGobjInst.Url = "https://www.yammer.com/SPDSpetro.com/users/brianj";
            yOGobjInst.Title = "CRM Certificed";
            yOGobjInst.Description = "Please join me in conguratulating Brian Johnson on his achievement";
            yOGobjInst.Image = "https://www.yammer.com/api/v1/uploaded_files/29860625/version/28812608/preview/UAPP_LOGO.png";
            yOGobjInst.Type = "person";
            yOG_obj.Activity.Object = yOGobjInst;
            string postData = yOG_obj.ToString();
            string activityURL = WebConfigurationManager.AppSettings["activityURL"];
            string response = SPDSUniversityWebApplication.App_Code.YammerUtility.PostRequesttoYammer(postData, activityURL, txtaccesstoken.Text.ToString(), "application/json");

        }

        /// <summary>
        /// Posting a Video using Open Graph
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnWriteDataOGVideo_Click(object sender, EventArgs e)
        {
            SPDSUniversityWebApplication.App_Code.OG_GraphObj yOG_obj = new SPDSUniversityWebApplication.App_Code.OG_GraphObj();

            yOG_obj.Activity.Actor = new SPDSUniversityWebApplication.App_Code.OG_Actor("Pathik Rawal", "pr@spdsuniversity.onmicrosoft.com");
            yOG_obj.Activity.Message = "Explore Microsoft Dynamics CRM more deeply-Introduction to Microsoft Dynamics CRM 2013 .";
            yOG_obj.Activity.Action = "create";
            SPDSUniversityWebApplication.App_Code.OG_GraphObj_Instance yammergraphobjectinst = new SPDSUniversityWebApplication.App_Code.OG_GraphObj_Instance();

            yammergraphobjectinst.Url = "http://video.ch9.ms/ch9/62c8/87663cbb-5485-4264-b23d-371d2b7362c8/IntroToDynamicsCRM2013M02.mp3";
            yammergraphobjectinst.Title = "Introduction to Microsoft Dynamics CRM 2013";
            yammergraphobjectinst.Description = "Find out about accounts and contacts (and the relationship between them), activities, Yammer, views, importing data, and processes..";
            yammergraphobjectinst.Image = "https://www.yammer.com/api/v1/uploaded_files/29860625/version/28812608/preview/UAPP_LOGO.png";
            yammergraphobjectinst.Type = "video";


            yOG_obj.Activity.Object = yammergraphobjectinst;
            string postData = yOG_obj.ToString();
            string activityURL = WebConfigurationManager.AppSettings["activityURL"];
            string response = SPDSUniversityWebApplication.App_Code.YammerUtility.PostRequesttoYammer(postData, activityURL, txtaccesstoken.Text.ToString(), "application/json");

        }

        /// <summary>
        /// Writing to Yammer using Open Graph's Custom Objects
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnWriteDataOGCustom_Click(object sender, EventArgs e)
        {
            SPDSUniversityWebApplication.App_Code.OG_GraphObj yOG_obj = new SPDSUniversityWebApplication.App_Code.OG_GraphObj();

            yOG_obj.Activity.Actor = new SPDSUniversityWebApplication.App_Code.OG_Actor("Pathik Rawal", "pr@spdsuniversity.onmicrosoft.com");
            yOG_obj.Activity.Message = "A Survey on upcoming trainings.";
            yOG_obj.Activity.Action = "create";
            SPDSUniversityWebApplication.App_Code.OG_GraphObj_Instance yammergraphobjectinst = new SPDSUniversityWebApplication.App_Code.OG_GraphObj_Instance();

            yammergraphobjectinst.Url = "http://localhost:43615/Survey.aspx";
            yammergraphobjectinst.Title = "A Survey on upcoming trainings";
            yammergraphobjectinst.Description = "A survey on upcoming trainings";
            yammergraphobjectinst.Image = "https://www.yammer.com/api/v1/uploaded_files/29860625/version/28812608/preview/UAPP_LOGO.png";
            yammergraphobjectinst.Type = "training_object:survey";

            yOG_obj.Activity.Object = yammergraphobjectinst;
            string postData = yOG_obj.ToString();
            string activityURL = WebConfigurationManager.AppSettings["activityURL"];
            string response = SPDSUniversityWebApplication.App_Code.YammerUtility.PostRequesttoYammer(postData, activityURL, txtaccesstoken.Text.ToString(), "application/json");

        }








    }
}