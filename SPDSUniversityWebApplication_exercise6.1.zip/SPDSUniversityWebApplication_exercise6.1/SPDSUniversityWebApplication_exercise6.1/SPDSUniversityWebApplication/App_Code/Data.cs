﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Json;
using System.IO;
using System.Diagnostics;

namespace SPDSUniversityWebApplication.App_Code
{

    [DataContract]
    public class TokenResponse
    {
        [DataMember(Name = "user_id")]
        public string UserID { get; set; }

        [DataMember(Name = "network_id")]
        public string NetworkID { get; set; }

        [DataMember(Name = "network_permalink")]
        public string NetworkPermaLink { get; set; }

        [DataMember(Name = "network_name")]
        public string NetworkName { get; set; }

        [DataMember(Name = "token")]
        public string Token { get; set; }
    }

    [DataContract]
    public class AccessToken : SerializedJson<AccessToken>
    {
        [DataMember(Name = "access_token")]
        public TokenResponse TokenResponse { get; set; }

        [DataMember(Name = "user")]
        public User CurrentUser { get; set; }

        public AccessToken()
        {
            this.TokenResponse = new TokenResponse();
            this.CurrentUser = new User();
        }
    }


}
