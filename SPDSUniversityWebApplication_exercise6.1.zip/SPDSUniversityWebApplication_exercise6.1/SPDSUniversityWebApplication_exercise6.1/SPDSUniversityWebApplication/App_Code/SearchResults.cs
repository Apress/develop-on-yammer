﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Runtime.Serialization;

namespace SPDSUniversityWebApplication.App_Code
{
    [DataContract]
    public class SearchResults : SerializedJson<SearchResults>
    {
        [DataMember(Name = "messages")]
        public YammerPosts Results { get; set; }

    }

}
