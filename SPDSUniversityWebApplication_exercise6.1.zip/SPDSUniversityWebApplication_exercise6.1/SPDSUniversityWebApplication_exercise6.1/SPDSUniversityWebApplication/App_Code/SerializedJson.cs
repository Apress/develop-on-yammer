﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Json;
using System.IO;


namespace SPDSUniversityWebApplication.App_Code
{
    [Serializable]
    public abstract class SerializedJson<T> where T : new()
    {

        public static T GetObjectInstanceFromJson(string data)
        {
            T returnInstance = default(T);

            try
            {
                MemoryStream m_stream = new MemoryStream();
                byte[] buf = System.Text.UTF8Encoding.UTF8.GetBytes(data);
                m_stream.Write(buf, 0, Convert.ToInt32(buf.Length));
                m_stream.Position = 0;
                DataContractJsonSerializer sdc_JSON_Ser = new DataContractJsonSerializer(typeof(T));
                returnInstance = (T)sdc_JSON_Ser.ReadObject(m_stream);
            }
            catch (Exception ex)
            {

            }

            return returnInstance;
        }

    }

}
