﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Runtime.Serialization;

namespace SPDSUniversityWebApplication.App_Code
{
    [DataContract]
    public class YammerPost
    {
        [DataMember(Name = "id")]
        public string ID { get; set; }

        [DataMember(Name = "sender_id")]
        public string SenderID { get; set; }

        [DataMember(Name = "replied_to_id")]
        public string RepliedToID { get; set; }

        [DataMember(Name = "created_at")]
        public string CreatedAt { get; set; }

        [DataMember(Name = "network_id")]
        public string NetworkID { get; set; }

        [DataMember(Name = "message_type")]
        public string MessageType { get; set; }

        [DataMember(Name = "sender_type")]
        public string SenderType { get; set; }

        [DataMember(Name = "url")]
        public string Url { get; set; }

        [DataMember(Name = "web_url")]
        public string WebUrl { get; set; }

        [DataMember(Name = "group_id")]
        public string GroupId { get; set; }

        [DataMember(Name = "body")]
        public YammerPostContent MessageContent { get; set; }

        [DataMember(Name = "rich")]
        public YammerPostContent MessageContent1 { get; set; }

        [DataMember(Name = "thread_id")]
        public string ThreadID { get; set; }

        [DataMember(Name = "client_type")]
        public string ClientType { get; set; }

        [DataMember(Name = "client_url")]
        public string ClientUrl { get; set; }

        [DataMember(Name = "system_message")]
        public bool SystemMessage { get; set; }

        [DataMember(Name = "direct_message")]
        public bool DirectMessage { get; set; }

        [DataMember(Name = "chat_client_sequence")]
        public string ChatClientSequence { get; set; }

        [DataMember(Name = "content_excerpt")]
        public string ContentExcerpt { get; set; }

        [DataMember(Name = "language")]
        public string Language { get; set; }

        [DataMember(Name = "privacy")]
        public string privacy { get; set; }

        [DataMember(Name = "group_created_id")]
        public string group_created_id { get; set; }

        [DataMember(Name = "liked_by")]
        public YammerPostLikedBy YammerPostLikedBy { get; set; }

        public YammerPost()
        {

            this.MessageContent = new YammerPostContent();
        }
    }

    [DataContract]
    public class YammerPostContent
    {
        [DataMember(Name = "parsed")]
        public string ParsedText { get; set; }

        [DataMember(Name = "plain")]
        public string PlainText { get; set; }

        [DataMember(Name = "rich")]
        public string RichText { get; set; }

    }

    [DataContract]
    public class YammerPostLikedBy
    {
        [DataMember(Name = "count")]
        public int Count { get; set; }

        [DataMember(Name = "names")]
        public List<YammerLikedbyNames> Names { get; set; }



    }

    [DataContract]
    public class YammerLikedbyNames
    {
        [DataMember(Name = "full_name")]
        public string FullName { get; set; }

        [DataMember(Name = "permalink")]
        public string Permalink { get; set; }

        [DataMember(Name = "user_id")]
        public int Userid { get; set; }

        [DataMember(Name = "network_id")]
        public int Networkid { get; set; }

    }

    [DataContract]
    public class YammerPosts : SerializedJson<YammerPosts>
    {
        [DataMember(Name = "messages")]
        public List<YammerPost> Posts { get; set; }

        public YammerPosts()
        {
            this.Posts = new List<YammerPost>();
        }
    }
}
