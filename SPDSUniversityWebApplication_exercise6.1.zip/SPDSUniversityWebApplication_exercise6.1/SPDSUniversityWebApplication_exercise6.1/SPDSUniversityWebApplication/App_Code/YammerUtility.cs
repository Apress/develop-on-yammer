﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Net;
using System.IO;
using System.Text;

namespace SPDSUniversityWebApplication.App_Code
{
    public class YammerUtility
    {
        private static HttpWebResponse HTTPWebRes;
        private static HttpWebRequest HTTPWebReq;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="Url"></param>
        /// <param name="authHeader"></param>
        /// <param name="AddCookies"></param>
        /// <returns></returns>
        public static string InvokeHttpGetRequest(string Url, string authHeader = null, bool AddCookies = false)
        {
            string results = string.Empty;

            try
            {
                HTTPWebReq = WebRequest.CreateHttp(Url);
                HTTPWebReq.Method = "GET";



                if (!string.IsNullOrEmpty(authHeader))
                    HTTPWebReq.Headers.Add("Authorization", "Bearer " + authHeader);

                HTTPWebRes = (HttpWebResponse)HTTPWebReq.GetResponse();

                Stream dataStream = HTTPWebRes.GetResponseStream();
                StreamReader reader = new StreamReader(dataStream);

                results = reader.ReadToEnd();

                reader.Close();
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error in MakeGetRequest: " + ex.Message);
            }

            return results;
        }

        /// <summary>
        /// PostRequesttoYammer
        /// </summary>
        /// <param name="Body"></param>
        /// <param name="url"></param>
        /// <param name="authHeader"></param>
        /// <param name="contentType"></param>
        /// <returns></returns>
        public static string PostRequesttoYammer(string Body, string url, string authHeader = null, string contentType = null)
        {
            string results = string.Empty;

            try
            {

                HTTPWebReq = WebRequest.CreateHttp(url);
                HTTPWebReq.Method = "POST";

                //if an authHeader was provided, add it as a Bearer token to the request
                if (!string.IsNullOrEmpty(authHeader))
                    HTTPWebReq.Headers.Add("Authorization", "Bearer " + authHeader);

                byte[] postByte = Encoding.UTF8.GetBytes(Body);

                if (string.IsNullOrEmpty(contentType))
                    HTTPWebReq.ContentType = "application/x-www-form-urlencoded";
                else
                    HTTPWebReq.ContentType = contentType;

                HTTPWebReq.ContentLength = postByte.Length;
                Stream RequestStream = HTTPWebReq.GetRequestStream();
                RequestStream.Write(postByte, 0, postByte.Length);
                RequestStream.Close();

                HTTPWebRes = (HttpWebResponse)HTTPWebReq.GetResponse();
                RequestStream = HTTPWebRes.GetResponseStream();
                StreamReader streamReader = new StreamReader(RequestStream);

                results = streamReader.ReadToEnd();

                streamReader.Close();
                RequestStream.Close();
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error has occured in PostRequesttoYammer: " + ex.Message);
            }

            return results;
        }


    
    }
}
