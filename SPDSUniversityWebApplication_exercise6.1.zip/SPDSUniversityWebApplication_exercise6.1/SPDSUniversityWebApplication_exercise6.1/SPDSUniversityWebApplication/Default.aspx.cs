﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Configuration;

namespace SPDSUniversityWebApplication
{
    public partial class _Default : Page
    {
        /// <summary>
        /// Page load event to check if query string contains a key called "Code"
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {

            string qsCode = Request.QueryString["Code"];
            if (qsCode != null)
            {
                txtCode.Text = qsCode;
                Obtain_Access_Token();
                tblupcoming.Visible = true;
            }
            else
            {
                tblupcoming.Visible = false;
            }
        }


        /// <summary>
        /// Obtain the access Token
        /// </summary>
        private void Obtain_Access_Token()
        {

            string accessToken = default(string);
            string AccesTokenURL = WebConfigurationManager.AppSettings["AccessTokenURL"] + "client_id=" + WebConfigurationManager.AppSettings["client_id"] + "&client_secret=" + WebConfigurationManager.AppSettings["client_secret"] + "&code=" + txtCode.Text;
            string response = SPDSUniversityWebApplication.App_Code.YammerUtility.InvokeHttpGetRequest(AccesTokenURL);
            if (!string.IsNullOrEmpty(response))
            {
                SPDSUniversityWebApplication.App_Code.AccessToken jat = SPDSUniversityWebApplication.App_Code.AccessToken.GetObjectInstanceFromJson(response);

                if (!string.IsNullOrEmpty(jat.TokenResponse.Token))
                {
                    accessToken = jat.TokenResponse.Token;
                    lbllogin.Text = "Welcome " + jat.CurrentUser.FullName;
                    txtaccesstoken.Text = accessToken;
                    Session["accesstoken"] = accessToken;
                }
            }
        }

        /// <summary>
        /// Post to Yammer Button's Click event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnPost_Click(object sender, EventArgs e)
        {
            //Get the current URL of the Page
            string url = HttpContext.Current.Request.Url.AbsoluteUri;
            //Read the Message endpoint from web.config file
            string Messageendpoint = WebConfigurationManager.AppSettings["Messageendpoint"];

            ///Construct the messagebody
          //  string Messagebody = "group_id=4966305" + "&body=Hi All, We have seats available for upcoming trainings, Kindly self-nominate before the registration deadline. View all training using the below link: " + url;
            string Messagebody = "&body=Hi All, We have seats available for upcoming trainings, Kindly self-nominate before the registration deadline. View all training using the below link: " + url;

            //call the YammerUtlity's PostRequesttoYammer methis passing the message, endpoint and the access token stored in a text box
            string response = SPDSUniversityWebApplication.App_Code.YammerUtility.PostRequesttoYammer(Messagebody, Messageendpoint, txtaccesstoken.Text);

            if (!string.IsNullOrEmpty(response))
            {
                lblMessage.Text = "Message posted";
            }

        }

        /// <summary>
        /// Post to Yammer Button's Click event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnPostView_Click(object sender, EventArgs e)
        {
            Response.Redirect("YammerMessage.aspx");
        }

        /// <summary>
        /// Search Button Event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnSearch_Click(object sender, EventArgs e)
        {
            Response.Redirect("YammerSearch.aspx");
        }





    }
}