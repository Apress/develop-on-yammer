﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Configuration;

namespace SPDSUniversityWebApplication
{
    public partial class YammerMessage : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Load_YammerPost();
        }

        /// <summary>
        /// Load_YammerPost method invokes YammerUtility.InvokeHttpGetRequest and then the response is SerializedJson
        /// </summary>
        private void Load_YammerPost()
        {
            string response = default(string);
            //Read the Message endpoint from web.config file
            string Messageendpoint = WebConfigurationManager.AppSettings["Messageendpoint"];

            //call the YammerUtlity's PostRequesttoYammer methis passing the message, endpoint and the access token stored in a text box
            if (Session["accesstoken"] != null)
            {
                response = SPDSUniversityWebApplication.App_Code.YammerUtility.InvokeHttpGetRequest(Messageendpoint, Session["accesstoken"].ToString());

                SPDSUniversityWebApplication.App_Code.YammerPosts allposts = SPDSUniversityWebApplication.App_Code.YammerPosts.GetObjectInstanceFromJson(response);

                grdYammerMessage.DataSource = allposts.Posts;
                grdYammerMessage.DataBind();
            }

        }

    }
}