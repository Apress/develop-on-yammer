﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Configuration;

namespace SPDSUniversityWebApplication
{
    public partial class YammerSearch : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        /// <summary>
        /// Search Button event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnsearch_Click(object sender, EventArgs e)
        {
            string response = default(string);
            //Read the Message endpoint from web.config file
            string Messageendpoint = WebConfigurationManager.AppSettings["Searchendpoint"] + "?search=" + txtSearch.Text + "&page=" + txtPages.Text + "&num_per_page=" + txtItems.Text;

            //call the YammerUtlity's PostRequesttoYammer methis passing the message, endpoint and the access token stored in a text box
            if (Session["accesstoken"] != null)
            {
                response = SPDSUniversityWebApplication.App_Code.YammerUtility.InvokeHttpGetRequest(Messageendpoint, Session["accesstoken"].ToString());

                SPDSUniversityWebApplication.App_Code.SearchResults results = SPDSUniversityWebApplication.App_Code.SearchResults.GetObjectInstanceFromJson(response);

                grdYammerMessage.DataSource = results.Results.Posts;
                grdYammerMessage.DataBind();

            }

        }

    }
}